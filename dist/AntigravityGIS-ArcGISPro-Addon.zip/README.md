# AntigravityGIS by Sounny

[![Author](https://img.shields.io/badge/Author-Sounny-blue.svg)](https://sounny.com)
[![Website](https://img.shields.io/badge/Website-sounny.com-purple.svg)](https://sounny.com)
[![Platform](https://img.shields.io/badge/GIS-ArcGIS%20Pro-green.svg)](https://www.esri.com/en-us/arcgis/products/arcgis-pro/overview)
[![QGIS](https://img.shields.io/badge/QGIS-Planned%20(PyQGIS)-teal.svg)](qgis/README_QGIS.md)
[![AI Engine](https://img.shields.io/badge/AI-Google%20Antigravity-orange.svg)](https://antigravity.google)
[![License](https://img.shields.io/badge/License-Apache%202.0-brightgreen.svg)](LICENSE)

**AntigravityGIS by Sounny** is an AI-powered GIS Copilot framework built on the **Google Antigravity Python SDK**. Designed and created by **Sounny** ([sounny.com](https://sounny.com)), it allows GIS analysts, cartographers, and spatial automation engineers to execute natural-language geoprocessing, spatial data QA/QC, dataset inspection, and ArcPy workflow automation directly inside **ArcGIS Pro** (and soon **QGIS**) using your active **Google Antigravity Account**.

---

## 🏗️ Project Architecture

The codebase is cleanly structured into platform-agnostic core logic, ArcPy integration tools, and desktop Add-on bindings:

```
AntigravityGIS/
├── .agents/
│   └── rules/
│       └── gis_agent.md         # Custom agent safety, AI data privacy & GIS rules
├── .github/
│   └── workflows/
│       └── ci.yml               # Automated GitHub CI testing & release packaging
├── agent_core.py                # Core Antigravity Agent harness & ArcPy tools
├── arcgis/
│   └── AntigravityGIS.pyt       # ArcGIS Pro Python Toolbox Extension (.pyt)
├── qgis/
│   └── README_QGIS.md           # QGIS PyQGIS plugin architecture & roadmap
├── install_to_arcgis.ps1        # Automated PowerShell 1-Click Add-on Installer
├── package_addon.py             # Add-on release packager (.zip builder)
├── dist/
│   └── AntigravityGIS-ArcGISPro-Addon.zip
├── .gitignore                   # Git exclusion rules
├── requirements.txt             # Python dependencies
├── README.md                    # Project documentation
└── tests/
    └── test_agent_core.py       # Unit & integration test suite
```

---

## 🔑 Account Authentication & ArcPy Capabilities

- **Runs on your Google Antigravity Account**: Authenticates seamlessly via your active Google Antigravity account and local session runtime (`agy auth login`).
- **ArcPy Automation Tools**:
  - `inspect_arcgis_workspace`: Scans File Geodatabases / workspaces for feature classes, spatial references, and geometry record counts.
  - `describe_arcgis_dataset`: Retrieves field schemas, data types, spatial extent (`XMin`, `YMin`, `XMax`, `YMax`), and coordinate systems.
  - `run_arcpy_geoprocessing`: Dynamically executes ArcPy management and analysis tools (`Buffer`, `Clip`, `Intersect`, `Dissolve`).

---

## 🌍 Coming Soon: QGIS Integration (PyQGIS)

Because [`agent_core.py`](file:///g:/My%20Drive/AntigravityGIS/agent_core.py) is completely decoupled from desktop UI frameworks:
- A native **QGIS plugin** is currently in development under [`qgis/`](file:///g:/My%20Drive/AntigravityGIS/qgis/README_QGIS.md).
- It will bring the same **AntigravityGIS by Sounny** AI Copilot capabilities to QGIS users via PyQGIS, GDAL, and a dockable Qt panel!

---

## ⚠️ AI & Sensitive Data Privacy Notice

> **Data Security Disclaimer**: Prompts and spatial metadata are processed by Google Antigravity AI models. Be cautious when handling sensitive, confidential, or proprietary spatial datasets. Ensure compliance with your organization's data privacy policies.

---

## 🚀 Quickstart Guide for ArcGIS Pro Add-on Installation

### Option A: Automated 1-Click Installation

Run the PowerShell installer script:

```powershell
.\install_to_arcgis.ps1
```

This script:
1. Detects your ArcGIS Pro Python environment (`arcgispro-py3`).
2. Installs the `google-antigravity` SDK.
3. Automatically checks your Google Antigravity login status.
4. Deploys `AntigravityGIS.pyt` and `agent_core.py` to your user toolboxes directory (`%APPDATA%\Esri\ArcGISPro\ArcToolbox\MyToolboxes\AntigravityGIS`).

### Option B: Load Manual Add-on Toolbox into ArcGIS Pro

1. Launch **ArcGIS Pro**.
2. Open the **Catalog Pane** (`View` -> `Catalog Pane`).
3. Expand **Toolboxes**, right-click, and select **Add Toolbox**.
4. Browse to `%APPDATA%\Esri\ArcGISPro\ArcToolbox\MyToolboxes\AntigravityGIS\AntigravityGIS.pyt` (or [`arcgis/AntigravityGIS.pyt`](file:///g:/My%20Drive/AntigravityGIS/arcgis/AntigravityGIS.pyt)) and click **OK**.
5. Double-click **Antigravity AI Assistant (by Sounny)** under **Sounny AI Tools** in the Geoprocessing pane to start prompting off your Antigravity account!

---

## 📦 Building the Distributable Add-on Package

To package the add-on into a single distributable zip file:

```bash
python package_addon.py
```

The output bundle will be generated in [`dist/AntigravityGIS-ArcGISPro-Addon.zip`](file:///g:/My%20Drive/AntigravityGIS/dist/AntigravityGIS-ArcGISPro-Addon.zip).

---

## 🧪 Running Unit Tests

```bash
python -m unittest discover -s tests
```

---

## 👤 About the Author & Credits

**AntigravityGIS** was designed and created by **Sounny**.

- **Creator**: Sounny
- **Website**: [sounny.com](https://sounny.com)
- **Framework**: Google Antigravity Agent Engine & Esri ArcPy
- **Mission**: Empowering GIS professionals with AI-driven spatial automation and intelligence.
